const router = require("express").Router();
const registerRouter = require("../Register/register.router");
router.use("/api/Register", registerRouter);
module.exports = router;
