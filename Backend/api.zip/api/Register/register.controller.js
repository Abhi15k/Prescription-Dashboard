const { create, fetch } = require("./register.services");
module.exports = {
    add: (req, res) => {
        const body = req.body;
        create(body, (err, results) => {
            if (err) {
                return res.status(500).json({
                    Success: 0,
                    data: err
                })
            } else {
                return res.status(200).json({
                    Success: 1,
                    data: results
                });
            }
        })
    },
    get: (req, res) => {
        fetch((err, results) => {
            if (err) {
                return res.status(500).json({
                    Success: 0,
                    data: err
                })
            } else {
                return res.status(200).json({
                    Success: 1,
                    data: results
                });
            }
        })
    }

}