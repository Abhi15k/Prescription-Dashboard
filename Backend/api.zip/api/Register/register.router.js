const { add, get } = require("./register.controller");

const router = require("express").Router();
router.post("/add", add);
router.get("/", get)

module.exports = router;