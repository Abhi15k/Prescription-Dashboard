const pool = require("../../config/dbconfig");

module.exports = {
    create: (data, callBack) => {
        pool.query(
            'Select * from register where email=?',
            [data.email],
            (err, results) => {
                if (results == "") {
                    pool.query(
                        'insert into register(name,email,phone,password) values(?,?,?,?)',
                        [data.name,
                        data.email,
                        data.phone,
                        data.password],
                        (err, results) => {
                            if (err) {
                                return callBack(err);
                            } else {
                                return callBack(null, results);
                            }
                        }
                    );
                } else if (err) {
                    return callBack(err);
                } else {
                    err = "Email already exists";
                    return callBack(err);
                }
            });
    },
    fetch: (callBack) => {
        pool.query(
            'Select * from register',
            (err, results) => {
                if (err) {
                    return callBack(err);
                } else if (results == "") {
                    err = "data not found";
                    return callBack(err);
                }
                else {
                    return callBack(null, results);
                }
            }
        );
    }
}