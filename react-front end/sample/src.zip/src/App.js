import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from './Login.js';
import ChangePassword from './ChangePassword';
import Register from './Register.js';
import ForgotPassword from './ForgotPassword.js';

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/ForgotPassword' element={<ForgotPassword />} />
          <Route path='/ChangePassword' element={<ChangePassword />} />
        </Routes>
      </BrowserRouter>


    </>
  );
}

export default App;
