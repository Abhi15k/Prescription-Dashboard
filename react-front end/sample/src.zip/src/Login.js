
import { Box, Button, Container, Grid, Link, TextField } from '@mui/material'
import React, { useState } from 'react'

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');


    const [emailError, setEmailError] = useState(false);
    const [passwordError, setPasswordError] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (email === "") {
            setEmailError(true);
        } else if (!/^\S+@\S+\.\S+/.test(email)) {
            setEmailError(true);
        }
        else if (password === "") {
            setPasswordError(true);
        }
        else {
            alert("Login successfully")
        }
    }
    return (
        <>
            <Container component="main" maxWidth="xs">
                <Box sx={{
                    marginTop: 8,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center"
                }}>
                    <h2>Login</h2>
                    <Box component="form" sx={{ mt: 3 }}>
                        <Grid container spacing={2}>

                            <Grid item xs={12}>
                                <TextField name='email' id='email' value={email} error={emailError} helperText={emailError ? 'field is required' : ''} onChange={(e) => { setEmail(e.target.value); setEmailError(false); }} type="email" label="Email" autoFocus fullWidth required />
                            </Grid>

                            <Grid item xs={12}>
                                <TextField name='password' id='password' value={password} error={passwordError} helperText={passwordError ? 'field is required' : ''} onChange={(e) => { setPassword(e.target.value); setPasswordError(false); }} type="password" label="Password" autoFocus fullWidth required />
                            </Grid>

                            <Grid item xs={12}>
                                <Button type="submit" fullWidth variant="contained" onClick={handleSubmit}>LOGIN</Button>
                            </Grid>
                        </Grid>
                        <Grid container justifyContent="flex-start">
                            <Grid item>
                                <Link href="ForgotPassword" variant="body2">
                                    Forgot Password?
                                </Link>
                            </Grid>
                        </Grid>
                        <Grid container justifyContent="flex-end">
                            <Grid item>
                                <Link href="Register" variant="body2">
                                    Create new account
                                </Link>
                            </Grid>
                        </Grid>
                    </Box>
                </Box >
            </Container>
        </>
    )
}

export default Login